package com.example.myjavafx;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Admin_View_Profile_Controller {

    @FXML
    private Label usernameLabel;

    @FXML
    private Label dobLabel;

    @FXML
    private Label roleLabel;

    @FXML
    private Label workingHoursLabel;

    private Admin currentAdmin;



    /**
     * Populates the labels using the Admin's profile.
     *
     * @param admin The current admin whose profile is to be displayed.
     */
    public void initializeProfile(Admin admin) {
        this.currentAdmin = admin;

        if (currentAdmin != null) {
            // Manually populate the labels from the Admin fields
            usernameLabel.setText(currentAdmin.getUserName());
            dobLabel.setText(currentAdmin.getDateOfBirth());
            roleLabel.setText(currentAdmin.getRole());
            workingHoursLabel.setText(currentAdmin.getWorkingHours());
        } else {
            // Handle the case where the Admin object is null
            usernameLabel.setText("N/A");
            dobLabel.setText("N/A");
            roleLabel.setText("N/A");
            workingHoursLabel.setText("N/A");
        }
    }

    /**
     * Handles the action for the "Back" button.
     */
    @FXML
    public void handleBackButtonAction() {
        System.out.println("Return button clicked. Implement navigation logic here.");
    }
}

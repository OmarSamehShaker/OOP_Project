package com.example.myjavafx;

import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class AdminSignUpController {

    @FXML
    private DatePicker dobPicker;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField usernameField1;

    @FXML
    private TextField usernameField2;

}

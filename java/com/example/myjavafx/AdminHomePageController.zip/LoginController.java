package com.example.myjavafx;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private ComboBox<String> combo_box;

    @FXML
    private PasswordField password;

    @FXML
    private TextField username;

    private Database database;

    public LoginController() {
        this.database = new Database();
    }

    @FXML
    public void initialize() {
        combo_box.getItems().addAll("Admin", "Customer");
        combo_box.getSelectionModel().selectFirst();
    }

    @FXML
    private void handleLogin() {
        String enteredUsername = username.getText().trim();
        String enteredPassword = password.getText().trim();
        String selectedUserType = combo_box.getValue();

        if (enteredUsername.isEmpty() || enteredPassword.isEmpty() || selectedUserType == null) {
            showAlert(AlertType.WARNING, "Input Error", "Please fill in all fields.");
            return;
        }

        if (validateCredentials(enteredUsername, enteredPassword, selectedUserType)) {
            if ("Admin".equals(selectedUserType)) {
                handleAdminLogin(enteredUsername);
            } else {
                handleCustomerLogin(enteredUsername);
            }
        } else {
            showAlert(AlertType.ERROR, "Login Failed", "Invalid username or password.");
        }
    }

    private boolean validateCredentials(String username, String password, String userType) {
        User user = database.getUserByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return ("Admin".equals(userType) && user instanceof Admin) ||
                    ("Customer".equals(userType) && user instanceof Customer);
        }
        return false;
    }

    private void showAlert(AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void handleAdminLogin(String username) {
        User user = database.getUserByUsername(username);
        if (user instanceof Admin) {
            Admin admin = (Admin) user;
            Session.setLoggedInUser(admin);
            clearFields();
            goToNextPage("Admin");
        }
    }

    private void handleCustomerLogin(String username) {
        User user = database.getUserByUsername(username);
        if (user instanceof Customer) {
            Session.setLoggedInUser(user);
            clearFields();
            goToNextPage("Customer");
        }
    }

    private void goToNextPage(String userType) {
        try {
            String fxmlFile = "AdminHomePage.fxml";
            if ("Customer".equals(userType)) {
                fxmlFile = "CustomerHomePage.fxml";
            }

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlFile));
            Scene scene = new Scene(fxmlLoader.load());

            Stage stage = (Stage) username.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Home Page");
            stage.show();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Unable to load the homepage.");
        }
    }

    private void clearFields() {
        username.clear();
        password.clear();
        combo_box.getSelectionModel().clearSelection();
    }
}

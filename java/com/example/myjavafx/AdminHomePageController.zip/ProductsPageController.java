package com.example.myjavafx;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class ProductsPageController {

    @FXML
    private GridPane productGrid;

    @FXML
    private Button returnButton;

    public void initialize() {
        // Product details
        String[][] products = {
                {"Laptop", "High-performance laptop", "$999"},
                {"Smartphone", "Latest Android smartphone", "$799"},
                {"Tablet", "Lightweight and portable", "$499"},
                {"Smartwatch", "Track your fitness and time", "$199"},
                {"Wireless Earbuds", "Crystal-clear sound", "$129"},
                {"Gaming Console", "Next-gen gaming experience", "$499"},
                {"4K Monitor", "Ultra HD display", "$299"},
                {"Bluetooth Speaker", "Portable and powerful sound", "$89"},
                {"External Hard Drive", "1TB storage", "$59"},
                {"Drone", "Capture stunning aerial photos", "$699"}
        };

        int numColumns = 3; // Number of columns

        // Populate the grid with product details
        for (int i = 0; i < products.length; i++) {
            String name = products[i][0];
            String description = products[i][1];
            String price = products[i][2];

            Label nameLabel = new Label(name);
            Label descriptionLabel = new Label(description);
            Label priceLabel = new Label(price);
            Button detailsButton = new Button("Details");
            Button addToCartButton = new Button("Add to Cart");

            // Add an action handler for the "Add to Cart" button
            addToCartButton.setOnAction(e -> {
                showAlert(Alert.AlertType.INFORMATION, "Success", null, "Item added successfully!");
            });

            // Add an action handler for the "Details" button
            detailsButton.setOnAction(e -> {
                showAlert(Alert.AlertType.INFORMATION, "Product Details", name, "Description: " + description + "\nPrice: " + price);
            });

            // Create a VBox for each product
            VBox productBox = new VBox(10, nameLabel, descriptionLabel, priceLabel, detailsButton, addToCartButton);
            productBox.setAlignment(javafx.geometry.Pos.CENTER);
            productBox.setStyle("-fx-border-color: gray; -fx-border-width: 1; -fx-padding: 10;");

            // Allow productBox to grow with the grid cell
            GridPane.setHgrow(productBox, Priority.ALWAYS);
            GridPane.setVgrow(productBox, Priority.ALWAYS);

            // Add productBox to the grid
            productGrid.add(productBox, i % numColumns, i / numColumns); // Arrange in columns and rows
        }
    }

    @FXML
    private void handleReturn() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AdminHomePage.fxml"));
            Scene adminHomeScene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) returnButton.getScene().getWindow();
            stage.setScene(adminHomeScene);
            stage.setTitle("Admin Home Page");
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Navigation Error", null, "Unable to load the Admin Home Page.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
